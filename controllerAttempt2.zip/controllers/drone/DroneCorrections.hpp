#pragma once
#include <string>

extern DroneProperties state;


struct DroneCorrections
{
  double altitudeCorrection = 0.0;
  
  void printTelemetry()
  {

    std::cout << "Altitude Correction: " << altitudeCorrection << std::endl;
  
  }
};