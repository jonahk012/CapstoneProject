/*
This is the main file that will connect everything that i have made
including all of the flight controller, PID controllers, etc...
*/
#include "WebotsInterface.hpp"
#include "DroneProperties.hpp"
#include "AltitudePID.hpp"
#include "DroneCorrections.hpp"

WebotsInterface interface = WebotsInterface();

DroneProperties state;
AltitudePID aPID;
DroneCorrections corr;

int main()
{

  while(interface.update()) // returns true if the loop is continuing
  {
    //interface.printTelemetry();
    //state.printTelemetry();
    //corr.printTelemetry();
  }
}