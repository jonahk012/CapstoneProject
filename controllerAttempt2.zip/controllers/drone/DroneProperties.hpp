#pragma once

struct DroneProperties
{
  double x = 0.0;
  double y = 0.0;
  double altitude = 0.0;
  double previousAltitude = 0.0;
  
  double verticalVelocity = 0.0;
  
  double velocityRoll = 0.0;
  double velocityPitch = 0.0;
  double velocityYaw = 0.0;
  
  double roll = 0.0;
  double pitch = 0.0;
  double yaw = 0.0;
  // later add the desired into a file that contains the targets, can later add a path for it to follow
  double desiredAltitude = 1.0;
  
  
  bool update(const double* gpsValues, const double* gyroValues, const double* imuValues, double dt)
  {
    x = gpsValues[0];
    y = gpsValues[1];
    altitude = gpsValues[2];
    
    verticalVelocity = (gpsValues[2]-previousAltitude)/dt; // need to /dt but i dont have it rn
    
    velocityRoll = gyroValues[0];
    velocityPitch = gyroValues[1];
    velocityYaw = gyroValues[2];
    
    roll = imuValues[0];
    pitch = imuValues[1];
    yaw = imuValues[2];
    
    return true;
  }
  void printTelemetry()
  {

    std::cout << x << std::endl;
    std::cout << y << std::endl;
    std::cout << altitude << std::endl;
    std::cout << verticalVelocity << std::endl;
    std::cout << desiredAltitude << std::endl;
    
  
  }
};